<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/ppal.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/product.css')); ?>">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php
        $maingroupName = $maingroupName ?? '';
    ?>
    <script type="text/javascript">
        var products = <?php echo json_encode($products, 15, 512) ?>;
        let allProducts = products; // Global variable to store all products
    </script>
</head>
<body>
    <?php if (isset($component)) { $__componentOriginalf48658bf231623f33691b1f774e8db46 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf48658bf231623f33691b1f774e8db46 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.mainmenu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mainmenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf48658bf231623f33691b1f774e8db46)): ?>
<?php $attributes = $__attributesOriginalf48658bf231623f33691b1f774e8db46; ?>
<?php unset($__attributesOriginalf48658bf231623f33691b1f774e8db46); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf48658bf231623f33691b1f774e8db46)): ?>
<?php $component = $__componentOriginalf48658bf231623f33691b1f774e8db46; ?>
<?php unset($__componentOriginalf48658bf231623f33691b1f774e8db46); ?>
<?php endif; ?>
    <main> <!--class="mt-6" -->
        <aside>
            <div class="aside-container" name="main_group" id="main_group">
                <input type="hidden" name="current-group" id="current-group" value="<?php echo e($maingroup); ?>" />
                <input type="hidden" name="current-group-name" id="current-group-name" value="<?php echo e($maingroupName); ?>" />
                <input type="hidden" id="selected-brands" name="selected-brands" value="">
                <input type="hidden" id="selected-brands-name" name="selected-brands-name" value="">
                <input type="hidden" id="selected-categories" name="selected-categories" value="">
                <input type="hidden" id="selected-categories-name" name="selected-categories-name" value="">

                <div class="title">GRUPOS</div>
                <div class="button-container">
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button
                            class="department-button <?php echo e($maingroup == $department['id'] ? 'aside-button-active' : ''); ?>"
                            value="<?php echo e($department['id']); ?>" id="dep-<?php echo e($department['id']); ?>"
                            
                            onclick="departmentRoute('<?php echo e($department['name']); ?>')"
                            name="dep-<?php echo e($department['id']); ?>"><?php echo e($department['name']); ?></button>
                        <?php if($department['id'] == $maingroup): ?>
                            <?php
                                $maingroupName = $department['name'];
                            ?>
                            <script type="text/javascript">
                                const GroupTitle = document.getElementById('current-group-name');
                                GroupTitle.value = "<?php echo $department['name']; ?>";
                                //alert(NameInput.value);
                                //const currentButton = document.getElementById("dep-<?php echo $department['id']; ?>");
                                //departmentActions(currentButton);
                            </script>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div>
            <p></p>
            <div class="aside-container filter">
                <h3 class="title">LIMPIAR</h3>
                <div class="filter-container-one-column">
                    <div class="centered">Última actualización</div>
                    <div class="centered">
                        <strong><?php echo e(session()->has('lastUpdated') ? session('lastUpdated') : date('d/m/Y H:i:s')); ?></strong>
                    </div>
                    <div class="centered">
                        <form action="<?php echo e(route('refresh')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                        <button type="submit">Cargar Ahora</button>
                        </form>
                    </div>
                </div>
            </div>

        </aside>
        <section class="main-section" id="main-section">
            <div class="product-list">
                <div>
                    <h2 class="product-title" id="product-title" name="product-title"><?php echo e($searchText); ?>

                    </h2>
                </div>
                <div class="product-order">
                    <span class="product-list-title">Ordenar por</span>
                    <select name="order-options" id="order-options" > 
                        <option value="">Seleccionar</option>
                        <option value="price-plus">Mayor a Menor Precio</option>
                        <option value="price-less">Menor a Mayor Precio</option>
                        <option value="stock-plus">Mayor a Menor Stock</option>
                        <option value="stock-less">Menor a Mayor Stock</option>
                        <option value="brands">Marca</option>
                    </select>
                </div>
            </div>
            <?php
                $counter = 0;
                $perPage = request()->has('perPage') ? request()->perPage : 300; //18;
                //$page = session()->has('numberPage') ? session('numberPage') : 1;
                $page = request()->has('page') ? request()->page : 1;
                $total = request()->has('total') ? request()->total : count($products); //
                $start = ($page - 1) * $perPage;
                $end = $start + $perPage > $total ? $total : $start + $perPage;
                //dd($products);
                //dd("pag. " .$page . "= " .$perPage );
            ?>
            <div class="table-row" id="products-container">
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                    <?php if($key >= $start && $key < $end): ?>
                        <div class="card">
                            <div class="card-body">
                                <div class="quantity">
                                    <?php echo e(number_format($product['stock_quantity'], 0, ',', '.')); ?>

                                </div>
                                <h6 class="card-title"><?php echo e($product['name']); ?> </h6>
                                <div class="card-image">
                                    <img src="<?php echo e($product['image_1']); ?>" alt="<?php echo e($product['name']); ?>">
                                </div>
                            </div>
                            <div class="card-body-text">
                                <div class="card-text">
                                    

                                    <button
                                    onclick="ModalDetail(cleanQuotation('<?php echo e($product['name']); ?>'),
                                        cleanQuotation('<?php echo e($product['sku']); ?>'),
                                        <?php echo e($product['stock_quantity']); ?>, <?php echo e($product['regular_price']); ?>,
                                        '<?php echo e($product['image_1']); ?>', '<?php echo e($product['image_2']); ?>', '<?php echo e($product['image_3']); ?>', '<?php echo e($product['image_4']); ?>',
                                        '<?php echo e($product['currency']); ?>',
                                        cleanQuotation('<?php echo e($product['description']); ?>'),
                                        '<?php echo e($product['unit']); ?>',
                                        '<?php echo e($product['department']); ?>',
                                        cleanQuotation('<?php echo e($product['category']); ?>'),
                                        '<?php echo e($product['brand']); ?>', '<?php echo e($product['segment']); ?>',
                                        cleanQuotation('<?php echo e(htmlentities(str_replace("\r\n", ' | ', $product['attributes']))); ?>'),
                                        '<?php echo e($product['guarantee']); ?>', '<?php echo e($product['contact_agent']); ?>', '<?php echo e($product['contact_unit']); ?>',
                                        <?php echo e($product['dimension_length']); ?>, <?php echo e($product['dimension_width']); ?>, <?php echo e($product['dimension_height']); ?>,<?php echo e($product['dimension_weight']); ?>

                                    )">
                                        <?php echo e($product['sku']); ?> / <?php echo e($product['brand']); ?>

                                        
                                    </button>

                                </div>
                                <div class="card-text">
                                    <?php echo e('$ ' . number_format($product['regular_price'], 2, ',', '.')); ?>

                                    <?php echo e($product['currency']); ?> / <?php echo e($product['unit']); ?>

                                </div>
                            </div>
                        </div>
                        <?php
                            $counter++;
                        ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h1> No hay productos para la selección</h1>
                <?php endif; ?>

                
            </div>
        </section>

    </main>
    <footer>
        <p class="footer-top"> Recuerde refrescar la página para un inventario actualizado.</p>
        <div class="footer-medium">
            <div class="footer-medium-left">
                <p class="footer-title">Documentación</p>
                <p>Documentación técnica para API de Consulta de Inventarios</p>
            </div>
            <div class="footer-medium-right">
                <form action="<?php echo e(route('postman.stock')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit">API Postman</button>
                </form>
            </div>
        </div>
        <p class="footer-bottom">El contenido de este sitio, incluyendo textos, imágenes y código, es propiedad de SED
            INTERNATIONAL DE COLOMBIA S.A.S., y está protegido por las leyes internacionales de derecho de autor.</p>
    </footer>

    <div id="productWindow" class="modal" onclick="closeModal()">
        
        <form id="skuDetailForm" class="modal-container" method="get" action="#" class="p-6">
            <?php echo csrf_field(); ?>
            <div class="modal-card-title" id="prod_name"></div>
            <div class="filter-container-two-column">
                <div class="modal-card-body">
                    <div class="quantity" id="prod_stock"></div>
                    <div class="modal-card-image">
                        <img id="prod_img_1" src="" alt="">
                    </div>
                </div>
                <div class="modal-card-body">
                    <div class="modal-card-image">
                        <img id="prod_img_2" src="" alt="">
                    </div>
                </div>
                <div class="modal-card-body modal-card-hide">
                    <div class="modal-card-image">
                        <img id="prod_img_3" src="" alt="">
                    </div>
                </div>
                <div class="modal-card-body modal-card-hide">
                    <div class="modal-card-image">
                        <img id="prod_img_4" src="" alt="">
                    </div>
                </div>
            </div>
            <div class="modal-card-item-container">
                <div class="modal-card-item-division">
                    <div class="modal-card-item-title">Sku</div>
                    <div class="modal-card-item" id="prod_sku"></div>
                </div>
                <div class="modal-card-item-division">
                    <div class="modal-card-item-division">
                        <div class="modal-card-item-title">$</div>
                        <div class="modal-card-item" id="prod_price"></div>
                        <div class="modal-card-item" id="prod_currency"></div>
                    </div>
                    <div class="modal-card-item-division">
                        <div class="modal-card-item-title">/</div>
                        <div class="modal-card-item" id="prod_unit"></div>
                    </div>
                </div>
                <div class="modal-card-item-division">
                    <div class="modal-card-item-title">Stock</div>
                    <div class="modal-card-item" id="prod_stock_1"></div>
                </div>
            </div>
            <div class="modal-card-item-container">
                <div class="modal-card-item-division">
                    <div class="modal-card-item-title">Marca</div>
                    <div class="modal-card-item" id="prod_brand"></div>
                </div>
                <div class="modal-card-item-division">
                    <div class="modal-card-item-title"> Clasificación </div>
                    <div class="modal-card-item" id="prod_department"></div> *
                    <div class="modal-card-item" id="prod_category"></div> *
                    <div class="modal-card-item" id="prod_segment"></div>
                </div>
            </div>
            <div class="modal-card-item-container">
                <div class="modal-card-item-division">
                    <div class="modal-card-item-title">Peso</div>
                    <div class="modal-card-item" id="dimension_weight"></div>
                </div>
                <div class="modal-card-item-division">
                    <div class="modal-card-item-title"> Dimensiones Largo*Alto*Ancho </div>
                    <div class="modal-card-item" id="dimension_length"></div> *
                    <div class="modal-card-item" id="dimension_width"></div> *
                    <div class="modal-card-item" id="dimension_height"></div>
                </div>
            </div>
            <div class="modal-card-text" id="prod_description">
            </div>
            <div class="modal-card-text" id="prod_attributes">
            </div>
            <div class="modal-card-text" id="prod_guarantee">
            </div>
            <div class="modal-card-item-container">
                <div class="modal-card-item-division">
                    <div class="modal-card-item-title">Gerente de Producto</div>
                    <div class="modal-card-item" id="prod_contact"></div>
                </div>
                <div class="modal-card-item-division">
                    <div class="modal-card-item-title">División</div>
                    <div class="modal-card-item" id="prod_contact_unit"></div>
                </div>
            </div>
            <div class="filter-container-one-column centered distance-top">
                <button id="cerrar" onclick="closeModal()">Cerrar</button>
            </div>

        </form>
    </div>
</body>


<script type="text/javascript">
function filterProducts(products, selectedCategories, selectedBrands) {
    return products.filter(product => {
        const categoryMatch = selectedCategories.length === 0 || selectedCategories.includes(product.category);
        const brandMatch = selectedBrands.length === 0 || selectedBrands.includes(product.brand);
        return categoryMatch && brandMatch;
    });
}
function sortAndFilterProducts(products, criteria, selectedCategories, selectedBrands) {
    // First filter the products
    let filteredProducts = filterProducts(products, selectedCategories, selectedBrands);

    // Then sort the filtered products
    switch(criteria) {
        case 'price-plus':
            filteredProducts.sort((a, b) => b.regular_price - a.regular_price);
            break;
        case 'price-less':
            filteredProducts.sort((a, b) => a.regular_price - b.regular_price);
            break;
        case 'stock-plus':
            filteredProducts.sort((a, b) => b.stock_quantity - a.stock_quantity);
            break;
        case 'stock-less':
            filteredProducts.sort((a, b) => a.stock_quantity - b.stock_quantity);
            break;
        case 'brands':
            filteredProducts.sort((a, b) => a.brand.localeCompare(b.brand));
            break;
    }
    return filteredProducts;
}

function getSelectedFilters() {
    const selectedCategories = Array.from(document.querySelectorAll('input[name="cat-array"]:checked')).map(cb => cb.value);
    const selectedBrands = Array.from(document.querySelectorAll('input[name="brand-array"]:checked')).map(cb => cb.value);
    const orderCriteria = document.getElementById('order-options').value;

    return { selectedCategories, selectedBrands, orderCriteria };
}

function updateProductsDisplay() {

    const { selectedCategories, selectedBrands, orderCriteria } = getSelectedFilters();
    // update the title of filters
    const groupElement = document.getElementById('current-group-name');
    const title = groupElement.value;
    let categories = "";
    let brands = "";
    if (selectedCategories.length > 0) { categories = ` ${selectedCategories.join('-')}`; }
    if (selectedBrands.length > 0) { brands = ` ${selectedBrands.join('-')}`; }
    //alert('Update Products ' + title + ' '+ categories + ' ' + brands );
    const titleElement = document.getElementById('product-title');
    titleElement.textContent = `${title}${categories}${brands}`;

    const filteredAndSortedProducts = sortAndFilterProducts(allProducts, orderCriteria, selectedCategories, selectedBrands);
    generateCards(filteredAndSortedProducts);
}

document.addEventListener('DOMContentLoaded', (event) => {
    const categoryCheckboxes = document.querySelectorAll('input[name="cat-array"]');
    const brandCheckboxes = document.querySelectorAll('input[name="brand-array"]');
    const orderSelect = document.getElementById('order-options');
    const searchText = document.getElementById('search');
    categoryCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', () => updateProductsDisplay());
    });

    brandCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', () => updateProductsDisplay());
    });

    orderSelect.addEventListener('change', () => updateProductsDisplay());
    searchText.addEventListener('keyup', function(event) {
        //alert(event.key);
        if (event.key === 'Enter') { // || event.key === 'Tab'
            searchWilcardProduct();
        }
    });
    searchText.addEventListener('change', function(event) {
        //alert(event.key);
        searchWilcardProduct();
    });
});

    /**
     * activates the search route with the search text
     */
     function searchWilcardProduct() {
        const searchText = document.getElementById('search').value;
        if (searchText !== '') window.location.href = "<?php echo e(route('search', ['searchText' => ':searchText'])); ?>".replace(
            ':searchText', searchText);
    }

    // Si el usuario hace click en la x, la ventana se cierra
    function closeModal() {
        var modal = document.getElementById("productWindow");
        modal.style.display = "none";
    };
    //formating numbers
    function intlRound(number, decimals = 2) {
        if (number === null || number === undefined || number === '') {
            return ''; // Return empty string for invalid input
        }
        const options = {
            minimumFractionDigits: decimals, // Ensure at least 'decimals' digits after decimal point
            maximumFractionDigits: decimals, // Limit to 'decimals' digits after decimal point
        };

        const formatter = new Intl.NumberFormat('en-US',
            options); // Use US English locale for formatting without commas
        return formatter.format(number);
    }

    //validate strings
    function isEmpty(str) {
        return (!str || str.trim().length == 0);
    }
    //replace all cases, including end of line
    function replaceModelString(input, origin, replacement) {
        var output = input;
        if (isEmpty(input)) return "";
        while (output.includes(origin)) {
            output = output.replace(origin, replacement);
        }
        return output;
    }

    function ModalDetail(prod_name, prod_sku, prod_stock, prod_price, prod_img_1, prod_img_2, prod_img_3, prod_img_4,
        prod_currency, prod_description, prod_unit,
        prod_department, prod_category, prod_brand, prod_segment, prod_attributes,
        prod_guarantee, prod_contact, prod_contact_unit,
        dimension_length, dimension_width, dimension_height, dimension_weight
    ) {
        // Replace `<br>` tags with actual newlines
        const processedAttributes = replaceModelString(decodeURIComponent(prod_attributes), "&lt;br&gt;", " | ");
        // console.log(prod_attributes);
        // console.log(processedAttributes);
        var modal = document.getElementById("productWindow");
        var name = document.getElementById("prod_name");
        name.innerText = prod_name;
        var sku = document.getElementById("prod_sku");
        sku.innerText = prod_sku;
        var stock = document.getElementById("prod_stock");
        stock.innerText = intlRound(prod_stock, 0);
        var stock = document.getElementById("prod_stock_1");
        stock.innerText = intlRound(prod_stock, 0);
        var price = document.getElementById("prod_price");
        price.innerText = intlRound(prod_price, 2);
        var prod_img = document.getElementById("prod_img_1");
        prod_img.src = prod_img_1;
        prod_img.alt = prod_name;
        var prod_img = document.getElementById("prod_img_2");
        prod_img.src = prod_img_2;
        prod_img.alt = replaceModelString(prod_img_2, "https://sedcolombia.com.co/Imagenes_Vtex/", " ");
        var prod_img = document.getElementById("prod_img_3");
        prod_img.src = prod_img_3;
        prod_img.alt = replaceModelString(prod_img_3, "https://sedcolombia.com.co/Imagenes_Vtex/", " ");
        var prod_img = document.getElementById("prod_img_4");
        prod_img.src = prod_img_4;
        prod_img.alt = replaceModelString(prod_img_4, "https://sedcolombia.com.co/Imagenes_Vtex/", " ");
        var currency = document.getElementById("prod_currency");
        currency.innerText = prod_currency;
        var description = document.getElementById("prod_description");
        description.innerText = prod_description;
        var description = document.getElementById("prod_attributes");
        // description.innerHTML = `<pre>${processedAttributes}</pre>`;
        description.innerHTML = processedAttributes;
        var description = document.getElementById("prod_guarantee");
        description.innerText = prod_guarantee;
        var unit = document.getElementById("prod_unit");
        unit.innerText = prod_unit;
        var group = document.getElementById("prod_department");
        group.innerText = prod_department;
        var group = document.getElementById("prod_category");
        group.innerText = prod_category;
        var group = document.getElementById("prod_brand");
        group.innerText = prod_brand;
        var group = document.getElementById("prod_segment");
        group.innerText = prod_segment;
        var contact = document.getElementById("prod_contact");
        contact.innerText = prod_contact;
        var contact = document.getElementById("prod_contact_unit");
        contact.innerText = prod_contact_unit;
        var dimension = document.getElementById("dimension_length");
        dimension.innerText = intlRound(dimension_length, 0);
        var dimension = document.getElementById("dimension_width");
        dimension.innerText = intlRound(dimension_width, 0);
        var dimension = document.getElementById("dimension_height");
        dimension.innerText = intlRound(dimension_height, 0);
        var dimension = document.getElementById("dimension_weight");
        dimension.innerText = intlRound(dimension_weight, 0);

        modal.style.display = "block";
    }

    function hiddenButtons(groupId, groupName) {
        const productName = document.getElementById('current-group-name');
        const productTitle = document.getElementById('product-title');
        const productId = document.getElementById('current-group');
        const brands = document.getElementById('selected-brands');
        const brandsName = document.getElementById('selected-brands-name');
        const categories = document.getElementById('selected-categories');
        const categoriesName = document.getElementById('selected-categories-name');
        // console.log("group " + groupName);
        // console.log("hidden input");
        // console.log(hiddenInput.value);
        productTitle.textContent = groupName;
        productName.value = groupName;
        brands.value = "";
        brandsName.value = "";
        categories.value = "";
        categoriesName.value = "";
        productId.value = groupId;
        // console.log("id " + groupId);
        // console.log("hidden id");
        // console.log(productId.value);
    }

    function addBrandToList(checkbox, brandName, groupName) {
        const brandListElement = document.getElementById('selected-brands');
        const brandNamesElement = document.getElementById('selected-brands-name');
        let selectedBrands = brandListElement.value ? brandListElement.value.split(',') :
    []; // Get existing or create empty array
        let selectedBrandsName = brandNamesElement.value ? brandNamesElement.value.split(',') : [];
        if (checkbox.checked) {
            selectedBrands.push(checkbox.value); // Add brand name if checkbox is checked
            selectedBrandsName.push(checkbox.value);
        } else {
            selectedBrands = selectedBrands.filter(brand => brand !== checkbox.value); // Remove brand name if unchecked
            selectedBrandsName = selectedBrands.filter(brand => brand !== brandName);
        }
        brandListElement.value = selectedBrands.join(','); // Update comma-separated list
        if (selectedBrands.length > 0)
            temporalIndicator();
        productBrandCards(groupName); // Call fetchProductsByBrands function and create cards
        brandNamesElement.value = selectedBrandsName.join('-');
        const productTitle = document.getElementById('product-title');
        productTitle.textContent = brandNamesElement.value;

    }

    function addCategoryToList(checkbox, brandName, groupName) {
        const catListElement = document.getElementById('selected-categories');
        const catNamesElement = document.getElementById('selected-categories-name');
        let selectedCategories = catListElement.value ? catListElement.value.split(',') :
    []; // Get existing or create empty array
        let selectedCatsName = catNamesElement.value ? catNamesElement.value.split(',') : [];
        if (checkbox.checked) {
            selectedCategories.push(checkbox.value); // Add brand name if checkbox is checked
            selectedCatsName.push(checkbox.value);
        } else {
            selectedCategories = selectedCategories.filter(brand => brand !== checkbox
            .value); // Remove brand name if unchecked
            selectedCatsName = selectedBrands.filter(brand => brand !== brandName);
        }
        catListElement.value = selectedCategories.join(','); // Update comma-separated list
        if (selectedCategories.length > 0)
            temporalIndicator();
        productCategoriesCards(groupName); // Call fetchProductsByBrands function and create cards
        catNamesElement.value = selectedCatsName.join('-');
        const productTitle = document.getElementById('product-title');
        productTitle.textContent = catNamesElement.value;

    }
/*
    // read department name
    function DepartmentName() {
        const departmentName = document.getElementById('current-group-name');
        return departmentName.value;
    }
*/


    function productBrandCards(groupName) {
        fetchProductsByBrands(groupName)
            .then(products => generateCards(products))
            .catch(error => console.error(error));
    }

    function productCategoriesCards(groupName) {
        fetchProductsByCategories(groupName)
            .then(products => generateCards(products))
            .catch(error => console.error(error));
    }

    function temporalIndicator() {
        const cardsContainer = document.getElementById("products-container");
        cardsContainer.innerHTML = ""; // Clear existing content
        const temporal = document.createElement("div");
        temporal.id = "temporal";
        temporal.classList.add("temporal");
        const temporal_title = document.createElement("label");
        temporal_title.textContent = "En Proceso ...";
        const temporal_progress = document.createElement("progress");
        temporal_progress.max = 100;
        temporal_progress.value = 70;
        temporal.appendChild(temporal_title);
        temporal.appendChild(temporal_progress);
        cardsContainer.appendChild(temporal);
    }

    // create visual cards
    function generateCards(products) {
        const cardsContainer = document.getElementById("products-container");
        cardsContainer.innerHTML = ""; // Clear existing content

        if (products.length > 0) {
            products.forEach(product => {
                const card = document.createElement("div");
                card.classList.add("card");

                const cardBody = document.createElement("div");
                cardBody.classList.add("card-body");

                const quantity = document.createElement("div");
                quantity.classList.add("quantity");
                quantity.textContent = intlRound(product.stock_quantity, 0);

                const cardTitle = document.createElement("h6");
                cardTitle.classList.add("card-title");
                cardTitle.textContent = product.name;

                const cardImage = document.createElement("div");
                cardImage.classList.add("card-image");

                const image = document.createElement("img");
                image.src = product.image_1;
                image.alt = product.name;

                cardImage.appendChild(image);

                const cardBodyText = document.createElement("div");
                cardBodyText.classList.add("card-body-text");

                const cardText = document.createElement("div");
                cardText.classList.add("card-text");

                const button = document.createElement("button");
                // ModalDetail function call with product data
                button.onclick = function() {
                    ModalDetail(product.name, product.sku, product.stock_quantity, product.regular_price,
                        product.image_1, product.image_2, product.image_3, product.image_4,
                        product.currency, product.description, product.unit,
                        product.department, product.category, product.brand, product.segment,
                        product.attributes, product.guarantee, product.contact_agent, product.contact_unit,
                        product.dimension_length, product.dimension_width, product.dimension_height, product.dimension_weight
                    );
                };

                button.textContent = product.sku + ' / ' + product.brand;

                const priceText = document.createElement("div");
                priceText.classList.add("card-text");
                priceText.textContent = '$ ' + intlRound(product.regular_price, 2) + ' ' + product.currency +
                    ' / ' + product.unit;

                cardText.appendChild(button);
                cardText.appendChild(priceText);

                cardBodyText.appendChild(cardText);

                cardBody.appendChild(quantity);
                cardBody.appendChild(cardTitle);
                cardBody.appendChild(cardImage);
                cardBody.appendChild(cardBodyText);

                card.appendChild(cardBody);

                cardsContainer.appendChild(card);
            });
        } else {
            const card = document.createElement("h1");
            card.textContent = "No hay productos para la selección";
            cardsContainer.appendChild(card);
        }
    }

    //validate abilities permission for auth model sanctum
    function fetchAbilities() {
        return new Promise((resolve, reject) => {
            fetch(`/profile/abilities`)
                .then(response => response.json())
                .then(data => {
                    resolve(data);
                })
                .catch(error => {
                    console.error('Error fetching sanctum abilities:', error);
                    reject(error); // Pass error to the calling function
                });

        });
    }

    // fetch products by brand
    function fetchProductsByBrands(groupName) {
        const selectedBrands = document.getElementById('selected-brands').value;
        return new Promise((resolve, reject) => {
            fetch(`/products/brands/${groupName}/${selectedBrands}`)
                .then(response => response.json())
                .then(products => {
                    resolve(products);
                })
                .catch(error => {
                    console.error('Error fetching products by brands:', error);
                    reject(error); // Pass error to the calling function
                });

        });
    }

    // fetch products by brand
    function fetchProductsByCategories(groupName) {
        const selectedCategories = document.getElementById('selected-categories').value;
        return new Promise((resolve, reject) => {
            fetch(`/products/categories/${groupName}/${selectedCategories}`)
                .then(response => response.json())
                .then(products => {
                    resolve(products);
                })
                .catch(error => {
                    console.error('Error fetching products by brands:', error);
                    reject(error); // Pass error to the calling function
                });

        });
    }

    function departmentRoute(groupName) {
        temporalIndicator();
        const productTitle = document.getElementById('product-title');
        productTitle.textContent = groupName;
       //window.location.href = '/products/' + groupName;
        window.location.href = "<?php echo e(route('product.show', ['group' => ':group'])); ?>".replace(':group', groupName);
    }

    //replace ' for avoid arguments warnings
    function cleanQuotation(text) {
        text.replace(/'/g, '"');
        //alert(`${text}`);
        console.log(text);
        return text;
    }
    // pvr willcards start example  for id property. coul by class, etc: const startsAbc = document.querySelectorAll("[id^='abc']");
    // const buttons = document.querySelectorAll('.department-button');
    // buttons.forEach(button => button
    //     .addEventListener('click', () => departmentActions(button)));
</script>

</html>
<?php /**PATH C:\Server\SED\BodegaVirtual\sedvirtual\resources\views/product/search.blade.php ENDPATH**/ ?>