<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/ppal.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/product.css')); ?>">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body>
    <section class="error-container">
        <span><span>4</span></span>
        <span>1</span>
        <span><span>9</span></span>
    </section>

    <footer>
        <p class="footer-top"> No encontramos la página.</p>
        <div class="footer-medium">
            <div class="footer-medium-left">
                <p class="footer-title">Volver al inicio</p>
            </div>
            <div class="footer-medium-right">
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit">Inicio</button>
                </form>
            </div>
        </div>
        <p class="footer-bottom">Este sitio es propiedad de SED INTERNATIONAL DE COLOMBIA S.A.S., y está protegido por
            las leyes internacionales de derecho de autor.</p>
    </footer>

</body>

</html>
<?php /**PATH C:\Server\SED\BodegaVirtual\sedvirtual\resources\views/errors/419.blade.php ENDPATH**/ ?>