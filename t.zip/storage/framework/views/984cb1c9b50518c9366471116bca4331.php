<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Productos')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="table-row" id="productContainer">
        <?php
            $counter = 0;
            $perPage =  request()->has('perPage') ? request()->perPage : 4; //18;
            //$page = session()->has('numberPage') ? session('numberPage') : 1;
            $page = request()->has('page') ? request()->page : 1;
            $start = ($page - 1) * $perPage;
            $end = ($start + $perPage) > $total ? $total : $start + $perPage;
            //dd($products);
            //dd("pag. " .$page . "= " .$perPage );
        ?>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($key >= $start && $key < $end): ?>

                <div class="card">
                    <div class="card-body">
                        <div class="quantity">
                            <?php echo e(number_format($product['stock_quantity'], 0, ",", ".")); ?>

                        </div>
                        <h6 class="card-title"><?php echo e($product['name']); ?> - <?php echo e($product['stock_quantity']); ?></h6>
                        <div class="card-image" >
                            <img src="<?php echo e($product['image_1']); ?>" alt="<?php echo e($product['name']); ?>">
                        </div>
                    </div>
                    <div class="card-body-text"
                    onclick="openSkuDetailModal('<?php echo e($product['name']); ?>', '<?php echo e($product['sku']); ?>', '<?php echo e($product['stock_quantity']); ?>', '<?php echo e($product['regular_price']); ?>', '<?php echo e($product['image_1']); ?>')"
                    >
                        <p class="card-text"><?php echo e($product['sku']); ?></p>
                        <p class="card-text"><?php echo e('$ ' . number_format($product['regular_price'], 2, ",", ".")); ?></p>
                    </div>
                </div>
                <?php
                    $counter++;
                ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div id="more">
        <button id="loadMoreBtn">Ver Más <?php echo e($total); ?></button>
        <button id="moreBtn" class="main-button">Ver Más <?php echo e($total); ?></button>
        <input type="hidden" id="page" value="<?php echo e($page); ?>">
        <input type="hidden" id="perPage" value="<?php echo e($perPage); ?>">
        <input type="hidden" id="total" value="<?php echo e($total); ?>">
        <input type="hidden" id="counter" value="<?php echo e($counter); ?>">
    </div>

    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => 'skuDetail','name' => 'skuDetail',':show' => true,'focusable' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'skuDetail','name' => 'skuDetail',':show' => true,'focusable' => true]); ?>
        <form id="skuDetailForm" method="post" action="#" class="p-6">
            <?php echo csrf_field(); ?>
            <h2 id='product_modal_name' class="text-lg font-medium text-gray-900">
            </h2>

            <p id ='product_modal_sku' class="mt-1 text-sm text-gray-600">
            </p>
            <div class="mt-6">
                <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'product_modal_quantity','value' => 'Stock','class' => 'sr-only']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'product_modal_quantity','value' => 'Stock','class' => 'sr-only']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['id' => 'product_modal_quantity','name' => 'product_modal_quantity','type' => 'text','class' => 'mt-1 block w-3/4','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'product_modal_quantity','name' => 'product_modal_quantity','type' => 'text','class' => 'mt-1 block w-3/4','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
            </div>
            <div class="mt-6">
                <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'product_modal_price','value' => 'Price','class' => 'sr-only']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'product_modal_price','value' => 'Price','class' => 'sr-only']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['id' => 'product_modal_price','name' => 'product_modal_price','type' => 'text','class' => 'mt-1 block w-3/4','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'product_modal_price','name' => 'product_modal_price','type' => 'text','class' => 'mt-1 block w-3/4','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="quantity" id="product_modal_quantity_2">
                    </div>
                    <h6 class="card-title" id="product_modal_name_2"></h6>
                    <div class="card-image" >
                        <img id="product_modal_image_2" src="" alt="">
                    </div>
                </div>
                <div class="card-body-text">
                    <p class="card-text" id="product_modal_sku_2"></p>
                    <p class="card-text" id="product_modal_price_2"></p>
                </div>
            </div>

            <div class="mt-6 flex justify-end">
                <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['xOn:click' => '$dispatch(\'close\')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-on:click' => '$dispatch(\'close\')']); ?>
                    <?php echo e(__('Cerrar')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>

            </div>
        </form>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>

    <script>

        function openSkuDetailModal(name, sku, quantity, regularPrice, productImage) {
            // Mostrar el modal skuDetail
            console.log(name);
            //document.querySelector('[name="skuDetail"]').dispatchEvent(new CustomEvent('show'));
            document.getElementById("skuDetail").dispatchEvent(new CustomEvent('show'));
            // Actualizar los elementos del modal con los valores recibidos

            document.getElementById("product_modal_name").innerText = name;
            document.getElementById("product_modal_name_2").innerText = name;
            document.getElementById("product_modal_sku").innerText = sku;
            document.getElementById("product_modal_sku_2").innerText = sku;
            document.getElementById("product_modal_quantity").innerText = quantity;
            document.getElementById("product_modal_quantity_2").innerText = quantity;
            document.getElementById("product_modal_price").innerText = regularPrice;
            document.getElementById("product_modal_price_2").innerText = regularPrice;
            document.getElementById("product_modal_image_2").src = productImage;
            //$('#skuDetail').modal('show');

        }
    </script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            document.getElementById("skuDetailForm").addEventListener("submit", function(event) {
                event.preventDefault(); // Evitar el envío del formulario
                // Cerrar el modal
                document.querySelector('[name="skuDetail"]').dispatchEvent(new CustomEvent('close'));
            });
        });
    </script>
    <script type="text/javascript">
        document.addEventListener("DOMContentLoaded", function() {
        document.getElementById("moreBtn").addEventListener("click", function() {
            alert("moreBtn clicked");
            var productContainer = document.getElementById('productContainer');
            var currentPage = parseInt(document.getElementById('page').value);
            var perPage = parseInt(document.getElementById('perPage').value);
            var total = parseInt(document.getElementById('total').value);
            var counter = parseInt(document.getElementById('counter').value);

            var nextPage = currentPage + 1;
            var start = (nextPage - 1) * perPage;
            var end = Math.min(start + perPage, total);
            console.log( " start " + start + " end " + end);
            //console.log( <?php echo e($products[0]['name']); ?> );
            // <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            //     if (<?php echo e($key); ?> >= start && <?php echo e($key); ?> < end) {
            //         console.log( <?php echo e($product['part_num']); ?>);
            // <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            // Actualizar valores de la paginación
            document.getElementById('page').value = nextPage;
            document.getElementById('counter').value = counter + end - start;
            if (counter + end - start >= total) {
                loadMoreBtn.style.display = 'none';
            }


        });
        });
    </script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        var loadMoreBtn = document.getElementById('loadMoreBtn');
        loadMoreBtn.addEventListener('click', function() {
            console.log( " clic yeah ");
            var productContainer = document.getElementById('productContainer');
            var currentPage = parseInt(document.getElementById('page').value);
            var perPage = parseInt(document.getElementById('perPage').value);
            var total = parseInt(document.getElementById('total').value);
            var counter = parseInt(document.getElementById('counter').value);

            var nextPage = currentPage + 1;
            var start = (nextPage - 1) * perPage;
            var end = Math.min(start + perPage, total);
            console.log( " start " + start + " end " + end);
            // Mostrar más productos si hay más disponibles
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                if (<?php echo e($key); ?> >= start && <?php echo e($key); ?> < end) {
                    console.log( <?php echo e($product['part_num']); ?>);
                    var card = document.createElement('div');
                    card.className = 'card';
                    var bodyCard = document.createElement('div');
                    bodyCard.className = 'card-body';
                    var quantity = document.createElement('div');
                    quantity.className = 'quantity';
                    quantity.textContent = '<?php echo e(number_format($product['stock_quantity'], 0, ",", ".")); ?>';
                    var cardTitle = document.createElement('h6');
                    cardTitle.className = 'card-title';
                    cardTitle.textContent = '<?php echo e($product['name']); ?>';
                    var cardImage = document.createElement('div');
                    cardImage.className = 'card-image';
                    var image = document.createElement('img');
                    image.src = '<?php echo e($product['image_1']); ?>';
                    image.alt = '<?php echo e($product['name']); ?>';
                    cardImage.appendChild(image);
                    bodyCard.appendChild(quantity);
                    bodyCard.appendChild(cardTitle);
                    bodyCard.appendChild(cardImage);
                    card.appendChild(bodyCard);
                    var bodyText = document.createElement('div');
                    bodyText.className = 'card-body-text';
                    bodyText.addEventListener('click', openSkuDetailModal('<?php echo e($product['name']); ?>', '<?php echo e($product['sku']); ?>',
                        '<?php echo e(number_format($product['stock_quantity'], 0, ",", ".")); ?>',
                        '<?php echo e('$ ' . number_format($product['regular_price'], 2, ",", ".")); ?>' ,
                        '<?php echo e($product['image_1']); ?>' ));
                    var cardText1 = document.createElement('p');
                    cardText1.className = 'card-text';
                    cardText1.textContent = '<?php echo e($product['sku']); ?>';
                    var cardText2 = document.createElement('p');
                    cardText2.className = 'card-text';
                    cardText2.textContent = '<?php echo e('$ ' . number_format($product['regular_price'], 2, ",", ".")); ?>';
                    bodyText.appendChild(cardText1);
                    bodyText.appendChild(cardText2);
                    card.appendChild(bodyText);
                    productContainer.appendChild(card);
                }
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            // Actualizar valores de la paginación
            document.getElementById('page').value = nextPage;
            document.getElementById('counter').value = counter + end - start;
            if (counter + end - start >= total) {
                loadMoreBtn.style.display = 'none';
            }
        });
    });
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Server\SED\BodegaVirtual\sedvirtual\resources\views/product/index.blade.php ENDPATH**/ ?>