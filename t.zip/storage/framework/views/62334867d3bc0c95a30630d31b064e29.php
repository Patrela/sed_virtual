<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>SED Inventario MU</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/ppal.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/product.css')); ?>">
    <!-- Fonts -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">

    <!-- Styles -->

</head>

<body class="antialiased dark:bg-black dark:text-white/50">
    <div class="bg-gray-50 text-black/50 dark:bg-black dark:text-white/50">
        

        <div
            class="relative min-h-screen flex flex-col items-center justify-center selection:bg-[#FF2D20] selection:text-white">
            <div class="relative w-full max-w-2xl px-6 lg:max-w-7xl">
                <header class="mainmenu grid grid-cols-3 items-center gap-2 py-10 lg:grid-cols-3">

                    <div class="flex lg:justify-left lg:col-start-1">
                        <?php if (isset($component)) { $__componentOriginal8892e718f3d0d7a916180885c6f012e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8892e718f3d0d7a916180885c6f012e7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'h-12 w-auto text-white lg:h-16 lg:text-[#FF2D20]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-12 w-auto text-white lg:h-16 lg:text-[#FF2D20]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $attributes = $__attributesOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $component = $__componentOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__componentOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
                    </div>

                    <?php if(Route::has('login')): ?>
                        <nav class="-mx-3 flex flex-1 justify-end">
                            <?php if(auth()->guard()->check()): ?>
                                <?php if(Route::has('profile.edit')): ?>
                                    
                                    <a href="<?php echo e(route('profile.edit')); ?>"
                                        class="navitem">
                                        Profile
                                    </a>
                                <?php endif; ?>
                                <?php if(Route::has('product.index')): ?>
                                    <a href="<?php echo e(route('product.index')); ?>" class="navitem">
                                        Products
                                    </a>
                                <?php endif; ?>
                            <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>" class="navitem">
                                    Log in
                                </a>

                                <?php if(Route::has('register')): ?>
                                    <a href="<?php echo e(route('register')); ?>" class="navitem">
                                        Register
                                    </a>
                                <?php endif; ?>
                                <?php if(Route::has('product.index')): ?>
                                    <a href="<?php echo e(route('product.index')); ?>" class="navitem">
                                        Products
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </nav>
                    <?php endif; ?>
                </header>

                <main > <!--class="mt-6" -->
                    <aside>
                        <div class="aside-container" name="main_group"  id="main_group">
                            <h3 class="title">GRUPOS</h3>
                            <button>Button 1</button>
                            <button>Button 2</button>
                            <button>Button 3</button>
                            <button>Más &nbsp;&nbsp;<i class="mx-3 fas fa-caret-down"></i></a></button>
                        </div>
                        <p></p>
                        <div class="aside-container" name="main_group"  id="main_group">
                            <h3 class="title">FILTROS</h3>
                            <button>Button 1</button>
                            <button>Button 2</button>
                            <button>Button 3</button>
                            <button>Más &nbsp;&nbsp;<i class="mx-3 fas fa-caret-down"></i></a></button>
                        </div>
                    </aside>

                    <section class="main-section">
                        <div class="card">
                            <div class="card-title">Card Title 1</div>
                            <div class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</div>
                            <img src="https://via.placeholder.com/150" alt="Card Image">
                        </div>
                        <!-- Add more cards here -->
                    </section>
                </main>

                <footer>
                    <p class="footer-top"> Recuerde refrescar la página para un inventario actualizado.</p>
                    <div class="footer-medium">
                        <div class="footer-medium-left">
                            <p class="footer-title">Documentación</p>
                            <p>Documentación técnica para API de Consulta de Inventarios</p>
                        </div>
                        <div class="footer-medium-right">
                            <form action="<?php echo e(route('postman.stock')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit">API Postman</button>
                              </form>

                        </div>
                    </div>
                    <p class="footer-bottom">El contenido de este sitio, incluyendo textos, imágenes y código, es propiedad de SED INTERNATIONAL DE COLOMBIA S.A.S., y está protegido por las leyes internacionales de derecho de autor.</p>
                </footer>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\Server\SED\BodegaVirtual\sedvirtual\resources\views/welcome.blade.php ENDPATH**/ ?>