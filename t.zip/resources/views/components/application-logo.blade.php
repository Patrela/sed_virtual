@props(['value' => 'SED INTERNATIONAL', 'attributes' => ''])
<img src="{{ asset('images/logosed01.png' ) }}" alt="{{ $value}}" $attributes }}>
